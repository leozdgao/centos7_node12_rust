.. cmake-module:: ../../Modules/CPackNSIS.cmake
