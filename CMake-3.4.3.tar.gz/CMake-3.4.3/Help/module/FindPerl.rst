.. cmake-module:: ../../Modules/FindPerl.cmake
